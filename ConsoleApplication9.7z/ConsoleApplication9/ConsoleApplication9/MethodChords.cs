﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    public static class MethodChords
    {
        public delegate double basedelegate(double x);
        static public double Result(basedelegate func, double a, double b, double x, double accur)
        {
            double newX = 0;
            double[,] X = { { a }, { x }, { b } };
            double[,] Y = { { func(a) }, { func(x) }, { func(b) } };
            if (func(b) * Interpol.SecondInterpolN(Y, X, x) > 0)
            {
                newX = x - ((func(x) * (b - x)) / (func(b) - func(x)));
            }
            else
            {
                newX = x - ((func(a) * (x - a)) / (func(x) - func(a)));
            }

            if (Math.Abs(newX - x) > accur)
            {
                return Result(func, a, b, newX, accur);
            }
            else
                return newX;
        }
    }
}
