﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    public static class CurTemp
    {
        public static double[,] Result(double[,] baseArray) {
            double[] freeMember = new double[baseArray.GetLength(1)-2];
            double[,] newData = new double[baseArray.GetLength(1) - 2, baseArray.GetLength(1) - 2];
            StreamWriter obj = new StreamWriter("DataCur.txt");
            for (int i = 0; i < baseArray.GetLength(1); ++i)
            {
                for (int j = 0; j < newData.GetLength(0); ++j)
                {
                    newData[j, j] = 3;
                    try
                    {
                        newData[j, j - 1] = -1;
                    }
                    catch
                    {
                        freeMember[j] += baseArray[1, 0];
                    }

                    try
                    {
                        newData[j, j + 1] = -1;
                    }
                    catch
                    {
                        freeMember[j] += baseArray[1, baseArray.GetLength(1)-1];
                    }

                    freeMember[j] += baseArray[1, j + 1];
                }

                double[,] newDataInc = new double[newData.GetLength(0), newData.GetLength(1) + 1];
                for (int it = 0; it < newData.GetLength(0); ++it)
                {
                    for (int jt = 0; jt < newData.GetLength(1); ++jt)
                        newDataInc[it, jt] = newData[it, jt];
                    newDataInc[it, newDataInc.GetLength(1) - 1] = freeMember[it];
                }

                Console.WriteLine();
                obj.WriteLine();
                obj.Write(i);
                Console.WriteLine("------------------------------");

                for (int it = 0; it < baseArray.GetLength(1); it++)
                {
                    Console.Write("{0,-6} ", Math.Round(baseArray[1, it], 3));
                    obj.Write("|" + "{0}", Math.Round(baseArray[1, it], 3));
                }
                Console.WriteLine();
                Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++");
                for (int it = 0; it < newDataInc.GetLength(0); it++)
                {
                    for (int j = 0; j < newDataInc.GetLength(1); j++)
                        Console.Write("{0,-6} ", Math.Round(newDataInc[it, j],3));

                    Console.WriteLine();
                }

                double[,] baseArrayNew = new double[baseArray.GetLength(0), baseArray.GetLength(1)];
                double[] resultData = Gauss.Gauss_Method(newDataInc);

                for (int it = 0; it < baseArray.GetLength(1); ++it) {
                    baseArrayNew[0, it] = baseArray[0, it];
                }

                for (int it = 1; it < baseArray.GetLength(1) - 1; ++it)
                {
                    baseArrayNew[1, it] = resultData[it-1];
                }
                baseArrayNew[1, baseArray.GetLength(1) - 1] = baseArray[1, baseArray.GetLength(1) - 1];
                baseArrayNew[1, 0] = baseArray[1, 0];
                baseArray = baseArrayNew;
                freeMember = new double[baseArray.GetLength(1) - 2];
            }
            obj.Close();
            return null;
        }
    }
}
