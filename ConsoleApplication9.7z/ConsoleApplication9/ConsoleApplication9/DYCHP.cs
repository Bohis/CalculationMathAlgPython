﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    static class DYCHP
    {
        public static double[] freeMem = null;
        public static double[,] Result(double[,] baseData)
        {
            double[] freeMember = new double[baseData.GetLength(1) / 2 * baseData.GetLength(1) / 2];
            double[,] newData = new double[baseData.GetLength(1) / 2 * baseData.GetLength(1) / 2, baseData.GetLength(1) / 2 * baseData.GetLength(1) / 2];

            for (int i = 0; i < newData.GetLength(0); ++i)
            {
                newData[i, i] = -4;

                if ((i + 1) % 3 != 0)
                {
                    try
                    {
                        newData[i, i + 1] = 1;
                    }
                    catch
                    {
                    }
                }
                else
                {
                    freeMember[i] += baseData[1, (int)((i) / 3) + baseData.GetLength(1) / 2];
                }

                if (((i) % 3 != 0))
                {
                    try
                    {
                        newData[i, i - 1] = 1;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    freeMember[i] += baseData[1, (int)((i + 1) / 3)];
                }


                try
                {
                    newData[i, i + 3] = 1;
                }
                catch
                {
                    freeMember[i] += baseData[0, ((i) % 3) + baseData.GetLength(1) / 2];
                }

                try
                {
                    newData[i, i - 3] = 1;
                }
                catch
                {
                    freeMember[i] += baseData[0, ((i) % 3)];
                }
                freeMember[i] = -freeMember[i];
            }

            for (int i = 0; i < newData.GetLength(0); i++)
            {
                for (int j = 0; j < newData.GetLength(1); j++)
                    Console.Write("{0,-5} ", newData[i, j]);

                Console.WriteLine();
            }
            Console.WriteLine();
            for (int i = 0; i < freeMember.GetLength(0); i++)
            {
                Console.Write("{0,-5} ", freeMember[i]);
            }

            double[,] newDataA = new double[newData.GetLength(0), newData.GetLength(1) + 1];
            for (int i = 0; i < newData.GetLength(0); i++)
            {
                for (int j = 0; j < newData.GetLength(1); j++)
                    newDataA[i, j] = newData[i, j];
                newDataA[i, newDataA.GetLength(1) - 1] = freeMember[i];
            }
            freeMem = freeMember;
            return newDataA;
        }
    }
}
