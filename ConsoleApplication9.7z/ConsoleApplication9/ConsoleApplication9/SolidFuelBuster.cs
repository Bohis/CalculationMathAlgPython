﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    static class SolidFuelBuster
    {
        public static double hMin = 0.0001;
        public static double hMax = 0.001;

        public delegate double basefunCalc(double[] Y);
        public delegate double basefunCalcNo();
        static void FCN(double[] Y, double[] K, basefunCalc[] funCalc)
        {
            for (int i = 0; i < K.GetLength(0); ++i)
            {
                K[i] = funCalc[i](Y);
            }
        }

        public static void Result(double[] baseValue, double t0, double H0, double D0, double h, double eps)
        {
            StreamWriter obj = new StreamWriter("SolidBuster.txt");

            double[] K1 = new double[baseValue.GetLength(0)];
            double[] K2 = new double[baseValue.GetLength(0)];
            double[] K3 = new double[baseValue.GetLength(0)];
            double[] K4 = new double[baseValue.GetLength(0)];

            double[] C = { 1 / 3.0, 2 / 3.0, 1 };
            double[] B = { 1 / 8.0, 3 / 8.0, 3 / 8.0, 1 / 8.0 };

            double A21 = 1 / 3.0;

            double A31 = -1 / 3.0;
            double A32 = 1;

            double A41 = 1;
            double A42 = -1;
            double A43 = 1;

            double epsMax = double.MinValue;
            double lenghtF = 0;
            double timeData = t0;
            double[] Eps = new double[2];

            basefunCalc speed = (double[] _baseValue) => Math.Exp(timeData);
            basefunCalc hlenghtFValue = (double[] _baseValue) => H0 - 2 * _baseValue[0];
            basefunCalc DlenghtFValue = (double[] _baseValue) => D0 - 2 * _baseValue[0];
            basefunCalc sqValue = (double[] _baseValue) => (2 * Math.PI * DlenghtFValue(_baseValue) / 2.0) * (hlenghtFValue(_baseValue) + DlenghtFValue(_baseValue) / 2.0);
            basefunCalc volumValue = (double[] _baseValue) => sqValue(_baseValue) * _baseValue[0];

            basefunCalc[] funCalc = { speed, volumValue};

            double[] newValue = new double[baseValue.GetLength(0)];

            obj.WriteLine(" t | l | Ud | Dd | Hd | Sd | Vd | Eps");
            Console.WriteLine("{0,-5}|{1,-5}|{2,-5}|{3,-5}|{4,-5}|{5,-5}|{6,-5}|{7,-5}", " t ", " l ", " Ud ", " Dd ", " Hd ",
                " Sd ", " Vd ", " Eps");
            
            obj.WriteLine(" " + timeData + " | " + lenghtF +" | " + speed(newValue) + " | " + DlenghtFValue(newValue) + " | " + hlenghtFValue(newValue) + " | " + sqValue(newValue) + " | " + newValue[1] + " | " + epsMax);
            
            Console.WriteLine("{0,-5}|{1,-5}|{2,-5}|{3,-5}|{4,-5}|{5,-5}|{6,-5}|{7,-5}",Math.Round(timeData,3),Math.Round(lenghtF,3),
                Math.Round(speed(newValue),3),Math.Round(DlenghtFValue(newValue),3),Math.Round(hlenghtFValue(newValue),3),
                Math.Round(sqValue(newValue), 3), Math.Round(newValue[1], 3), Math.Round(epsMax, 3));

            for (; hlenghtFValue(newValue) > 0 && DlenghtFValue(newValue) > 0; timeData += h)
            {
                #region 2h

                FCN(baseValue, K1, funCalc);
                for (int j = 0; j < newValue.GetLength(0); ++j)
                {
                    newValue[j] = baseValue[j] + 2 * h * (A21 * K1[j]);
                }

                FCN(newValue, K2, funCalc);
                for (int j = 0; j < newValue.GetLength(0); ++j)
                {
                    newValue[j] = baseValue[j] + 2 * h * (A31 * K2[j] + A32 * K1[j]);
                }

                FCN(newValue, K3, funCalc);
                for (int j = 0; j < newValue.GetLength(0); ++j)
                {
                    newValue[j] = baseValue[j] + 2 * h * (A41 * K3[j] + A42 * K2[j] + A43 * K1[j]);
                }

                FCN(newValue, K4, funCalc);
                for (int j = 0; j < newValue.GetLength(0); ++j)
                {
                    newValue[j] = baseValue[j] + 2 * h * (B[0] * K1[j] + B[1] * K2[j] + B[2] * K3[j] + B[3] * K4[j]);
                }

                Eps[ 0] = newValue[0];
                Eps[ 1] = newValue[1];

                #endregion

                #region 1h
                for (int u = 0; u != 1; ++u, timeData += h)
                {
                    FCN(baseValue, K1, funCalc);
                    for (int j = 0; j < newValue.GetLength(0); ++j)
                    {
                        newValue[j] = baseValue[j] + h * (A21 * K1[j]);
                    }

                    FCN(newValue, K2, funCalc);
                    for (int j = 0; j < newValue.GetLength(0); ++j)
                    {
                        newValue[j] = baseValue[j] + h * (A31 * K2[j] + A32 * K1[j]);
                    }

                    FCN(newValue, K3, funCalc);
                    for (int j = 0; j < newValue.GetLength(0); ++j)
                    {
                        newValue[j] = baseValue[j] + h * (A41 * K3[j] + A42 * K2[j] + A43 * K1[j]);
                    }

                    FCN(newValue, K4, funCalc);
                    for (int j = 0; j < newValue.GetLength(0); ++j)
                    {
                        newValue[j] = baseValue[j] + h * (B[0] * K1[j] + B[1] * K2[j] + B[2] * K3[j] + B[3] * K4[j]);
                    }

                    baseValue[0] = newValue[0];
                    baseValue[1] = newValue[1];
                }
                #endregion

                epsMax = Math.Abs(newValue[0] - Eps[0]) > Math.Abs(newValue[1] - Eps[1]) ? Math.Abs(newValue[0] - Eps[0]) : Math.Abs(newValue[1] - Eps[1]);

                if (epsMax > eps)
                {
                    timeData -= h;
                    if (h / 2.0 > hMin)
                        h /= 2.0;
                    else
                        h = hMin;
                }
                else
                if (epsMax < eps)
                {
                    if (2.0 * h < hMax)
                    {
                        h *= 2.0;
                    }
                    else
                    {
                        h = hMax;
                    }
                }
                lenghtF += h * speed(newValue);
                
                obj.WriteLine(" " + timeData + " | " + lenghtF + " | " + speed(newValue) + " | " + DlenghtFValue(newValue) + " | " + hlenghtFValue(newValue) + " | " + sqValue(newValue) + " | " + newValue[1] + " | " + epsMax);
                
                Console.WriteLine("{0,-5}|{1,-5}|{2,-5}|{3,-5}|{4,-5}|{5,-5}|{6,-5}|{7,-5}", Math.Round(timeData, 3), Math.Round(lenghtF, 3),
                 Math.Round(speed(newValue), 3), Math.Round(DlenghtFValue(newValue), 3), Math.Round(hlenghtFValue(newValue), 3),
                 Math.Round(sqValue(newValue), 3), Math.Round(newValue[1], 3), Math.Round(epsMax, 3));
            }
            obj.Close();
        }
    }
}
