﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    static class DerTwo
    {
        delegate double baseFunc(double x);
        public static double[,] Result(int n) { 
            double[,] arrayY = new double[n-1,n];
            double x = -1;
            double h = 0.2;
            int g = 1;
            baseFunc newX = (double d) => x + h * g;
            baseFunc funcY = (double _x) => h * h * (1 + newX(1) * newX(1)) - 2;  
            arrayY[0, 1] = 1;
            arrayY[0, 0] = funcY(1) ;
            g++;
            arrayY[0, n - 1] = -h * h;
            for (int i = 1; i < arrayY.GetLength(0) - 1; ++i,++g){
                try
                {
                    arrayY[i, i - 1] = 1;
                }
                catch { }
                try
                {
                    arrayY[i, i + 1] = 1;
                }
                catch { }
                arrayY[i, i] = funcY(1) ;
                arrayY[i, n - 1] = -h * h;
            }
            arrayY[n-2, n - 1] = -h * h;
            arrayY[n - 2, n - 3] = 1;
            arrayY[n - 2, n - 2] = funcY(1);
            return arrayY;
        }
    }
}
